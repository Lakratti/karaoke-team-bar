# karaoke-team-bar
Customer: Nataliya Shurigyna, Project: Karaoke Team Bar (Chelyabinsk)
